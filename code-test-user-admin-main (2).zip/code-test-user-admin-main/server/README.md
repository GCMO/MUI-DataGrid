User Admin Server
=================

# Get Started

- `npm run dev`
- The server will be running at `http://localhost:5000`

# Introduction

This is a simple backend application for managing users.
