User Admin Client
=================

# Get Started

- `npm run dev`
- The client will be running at `http://localhost:3000`

# Introduction

This is a simple frontend application for managing users.
