import { FC, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

export interface User {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  createDateTime: number;
}

interface UserDetailsParams extends Record<string, string> {
  id: string;
}

export const UserDetails = () => {
  const { id } = useParams<UserDetailsParams>();
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    fetch(`http://localhost:5000/users/${id}`)
      .then((res) => res.json()).then(setUser).catch((err) => {
      console.error(err);
      setUser(null);
    });
  }, []);

  return (
    <pre>
      <code>{JSON.stringify(user, null, 2)}</code>
    </pre>
  )
};
