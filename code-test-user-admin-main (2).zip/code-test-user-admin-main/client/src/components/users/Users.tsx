import { Box } from '@mui/material';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { User } from './UserDetails';

export const Users = () => {
  const [users, setUsers] = useState<Array<User>>([]);

  useEffect(() => {
    fetch('http://localhost:5000/users')
      .then((res) => res.json()).then(setUsers).catch((err) => {
      console.error(err);
      setUsers([]);
    });
  }, []);

  return (
    <Box>
      {users.map(({_id, ...user}, index) => (<p key={index}>id: <Link to={`/users/${_id}`}>{_id}</Link>{JSON.stringify(user)}</p>))}
    </Box>
  );
};
